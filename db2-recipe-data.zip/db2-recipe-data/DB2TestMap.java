import java.util.Map;
import org.geotools.data.db2.DB2NGDataStoreFactory;
import org.geotools.data.simple.SimpleFeatureSource;
import org.geotools.jdbc.JDBCDataStore;
import org.geotools.map.FeatureLayer;
import org.geotools.map.Layer;
import org.geotools.map.MapContent;
import org.geotools.styling.SLD;
import org.geotools.styling.Style;
import org.geotools.swing.JMapFrame;
import org.geotools.swing.data.JDataStoreWizard;

/**
 * Prompts the user for the DB2 connection values
 * and displays the contents on the screen in a map frame.
 *
 * This is a variation of the GeoTools Quickstart application 
 * used in documentation and tutorials.
 */
public class DB2TestMap {

    public static void main(String[] args) throws Exception {

        DB2NGDataStoreFactory factory = new DB2NGDataStoreFactory();        
        JDataStoreWizard wiz = new JDataStoreWizard(factory);
       
        if (wiz.showModalDialog() == 1) return; // return if cancel pressed
        Map<String,Object> connParms = wiz.getConnectionParameters();

        if (!factory.canProcess(connParms)) {
        	System.out.println("Some DB2 connection parameters missing");
        	return;
        };

        JDBCDataStore store = factory.createDataStore(connParms);

        // Create a map content
        MapContent map = new MapContent();
        map.setTitle("DB2 with Geotools");
        
        // Add the SJSTREETS table with basic line styling as a layer
        SimpleFeatureSource streets = store.getFeatureSource("SJSTREETS");  
        Style streetStyle = SLD.createSimpleStyle(streets.getSchema());
        Layer streetLayer = new FeatureLayer(streets, streetStyle);
        map.addLayer(streetLayer);
        
        // Now display the map
        JMapFrame.showMap(map);
    }
}

