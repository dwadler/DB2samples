package org.geotools.tutorial;

import java.util.HashMap;
import java.util.Map;

import org.geotools.data.Query;
import org.geotools.data.db2.DB2NGDataStoreFactory;
import org.geotools.data.simple.SimpleFeatureCollection;
import org.geotools.data.simple.SimpleFeatureSource;
import org.geotools.feature.FeatureIterator;
import org.geotools.filter.text.cql2.CQL;
import org.geotools.jdbc.JDBCDataStore;
import org.opengis.feature.simple.SimpleFeature;

/**
 * Hard-code the DB2 connection parameters. Issue queries using the GeoTools
 * API.
 *
 */
public class DB2TestAPI {

	public static void main(String[] args) throws Exception {

		// Create a factory for a DB2 connection
		DB2NGDataStoreFactory factory = new DB2NGDataStoreFactory();

		// Build the parameters needed for DB2 connection - modify as needed
		Map<String, Object> connParams = new HashMap<String, Object>();
		connParams.put("dbtype", "db2");
		connParams.put("schema", "OSUSER"); // case sensitive
		connParams.put("database", "ostest");
		connParams.put("port", "50000");
		connParams.put("host", "localhost");
		connParams.put("user", "osuser");
		connParams.put("passwd", "osuserpw");

		// Create the DataStore and connect to DB2
		JDBCDataStore store = factory.createDataStore(connParams);

		// Get all of the BANK features (only 2) and print some info
		SimpleFeatureSource banks = store.getFeatureSource("BANKS");
		SimpleFeatureCollection bankFeatures = banks.getFeatures();
		FeatureIterator<SimpleFeature> it1 = bankFeatures.features();
		try {
			while (it1.hasNext()) {
				SimpleFeature feature = it1.next();
				System.out.println(
						"Name: " + feature.getAttribute("NAME") + "; geometry: " + feature.getDefaultGeometry());
			}
		} finally {
			it1.close();
		}

		// Create a feature source for customers and get the bounds
		SimpleFeatureSource customers = store.getFeatureSource("CUSTOMERS");
		System.out.println("CUSTOMERS bounds: " + customers.getBounds());
		
		// Define a bounding box around all customers and count customers inside
		Query query = new Query("CUSTOMERS", CQL.toFilter("BBOX(GEOM, -121.95, 37.27,-121.84, 37.35)"));
		System.out.println("All CUSTOMERS count: " + customers.getCount(query));
		
		// Define a smaller bounding box and count customers inside
		query = new Query("CUSTOMERS", CQL.toFilter("BBOX(GEOM, -121.9,37.3,-121.8,37.48)"));
		System.out.println("Some CUSTOMERS Count: " + customers.getCount(query));
	}
}