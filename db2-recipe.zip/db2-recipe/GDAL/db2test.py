# Sample Python script using the GDAL/OGR API
# include OGR functionality
import ogr

# attempt to open a DB2 ODBC connection and check if it was successful
fileName = "DB2ODBC:DRIVER={IBM DB2 ODBC DRIVER};database=OSTEST;Hostname=localhost;PROTOCOL=TCPIP;port=50000;UID=osuser;PWD=osuserpw"
dataSource = ogr.Open( fileName )
if dataSource is None:
    print 'failed to open data source'
    quit()

# get the CUSTOMERS table as a layer and check if it was successful    
layer = dataSource.GetLayer("CUSTOMERS")
if layer is None:
     print 'failed to get layer'
     quit()

# get the count of the features in the layer     
count = layer.GetFeatureCount()
print 'Layer count: ', count

# get the geographic extent of the layer
extent = layer.GetExtent()
print 'Layer extent: ', extent

# get the first feature found and dump its attributes
feature = layer.GetNextFeature()
geometry = feature.GetGeometryRef()
feature.DumpReadable()

# set a query envelope so we get a subset of features
layer.SetSpatialFilterRect( -121.9, 37.3, -121.8, 37.4 )

# get the count of features within the query envelope        
count = layer.GetFeatureCount()
print 'Count: ', count    