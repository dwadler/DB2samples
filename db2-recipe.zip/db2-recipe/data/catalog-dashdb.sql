-- Change DASHDB to a node name for your environment; DASHDB is probably OK
-- Change dashdb-entry-yp-dal09-07.services.dal.bluemix.net to the IP address of the DashDB server
uncatalog node DASHDB;
uncatalog database BLUDB;
catalog tcpip node DASHDB remote dashdb-entry-yp-dal09-07.services.dal.bluemix.net server 50000;
catalog database BLUDB at node DASHDB;