-- create an EPSG standard spatial reference system for WGS84 if it doesn't already exit.
-- if it already exists, this will fail but that is fine.
-- the srs_id is 4326
-- the srs_name is WGS84_SRS_4326
call sysproc.ST_Create_srs( 
 'WGS84_SRS_4326' ,       
 4326,       
 -180.0,       
 5000000.0,     
 -90.0,           
 5000000,
 0,       
 1000,       
 0,       
 1000,            
 'GCS_WGS_1984',       
 'EPSG4326',           
     ?,        
     ?) ; 

-- Drop the table in case it already exists
DROP   TABLE banks;

CREATE TABLE banks (
   objectid      integer
  ,branch_id     integer
  ,name          varchar(20)
  ,street        varchar(25)
  ,city          varchar(10)
  ,state         char(2)
  ,zip           char(5)
  ,latitude      double
  ,longitude     double
  ,geom          db2gse.st_point
 )
;

-- Import the non-spatial columns
IMPORT FROM banks.ixf OF IXF METHOD P (1, 2, 3, 4, 5, 6, 7, 8, 9)
MESSAGES imp.msg
INSERT INTO banks(objectid, branch_id, name, street, city, state, zip, latitude, longitude)
;

-- Set the spatial column from the longitude and latitude
-- Note that longitude comes first in the parameter list
UPDATE banks
SET geom = db2gse.st_point(longitude, latitude, 4326)
;

-- Register the spatial column with the spatial reference system WGS84
-- The first parameter needs to be changed to your connection ID before running
CALL sysproc.st_register_spatial_column('SYSPROC','BANKS','GEOM','WGS84_SRS_4326',?,?);

-- Drop the table in case it already exists
DROP   TABLE customers;

CREATE TABLE customers (
   objectid      integer
  ,customer_id   integer
  ,name           varchar(20)
  ,street        varchar(25)
  ,city          varchar(10)
  ,state         char(2)
  ,zip           char(5)
  ,latitude      double
  ,longitude     double
  ,geom          db2gse.st_point
 )
;

-- Import the non-spatial columns
IMPORT FROM customers.ixf OF IXF METHOD P (1, 2, 3, 4, 5, 6, 7, 8, 9)
MESSAGES imp.msg
INSERT INTO customers(objectid, customer_id, name, street, city, state, zip, latitude, longitude)
;

-- Set the spatial column from the longitude and latitude
-- Note that longitude comes first in the parameter list
UPDATE customers
SET geom = db2gse.st_point(longitude, latitude, 4326)
;

-- Register the spatial column with the spatial reference system WGS84
-- The first parameter needs to be changed to your connection ID before running
CALL sysproc.st_register_spatial_column('SYSPROC','CUSTOMERS','GEOM','WGS84_SRS_4326',?,?);

-- Drop the table in case it already exists
DROP   TABLE sjstreets;

CREATE TABLE sjstreets (
   objectid      integer
  ,hwyname       char(32)
  ,wkt           varchar(2000)
  ,geom          db2gse.st_multilinestring
 )
;

-- Import the non-spatial columns
IMPORT FROM sjstreets.ixf OF IXF METHOD P (1, 2, 3)
MESSAGES imp.msg
INSERT INTO sjstreets(objectid, hwyname, wkt)
;

-- Set the spatial column from the well-known text representation
UPDATE sjstreets
SET geom = db2gse.st_multilinestring(wkt, 4326)
;

-- Register the spatial column with the spatial reference system WGS84
-- The first parameter needs to be changed to your connection ID before running
CALL sysproc.st_register_spatial_column('SYSPROC','SJSTREETS','GEOM','WGS84_SRS_4326',?,?);


