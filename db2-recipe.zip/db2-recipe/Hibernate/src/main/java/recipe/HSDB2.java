package recipe;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import java.util.Date;
import java.util.List;
import java.util.Iterator;

import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.Point;
import org.locationtech.jts.io.ParseException;
import org.locationtech.jts.io.WKTReader;

import java.net.URL;
import java.net.URLClassLoader;

/**
 * @author David Adler, Adtech Geospatial
 * @author Karel Maesen, Geovise BVBA
 */
public class HSDB2 {
	
	EntityManager em;
	EntityManagerFactory emFactory;	

	public static void main(String[] args) {
		HSDB2 mgr = new HSDB2();

		if (args.length < 1) {
			mgr.help();
			return;
		}

		String operation = args[0];
		mgr.createEntityManager();
		switch (operation) {
			case "listnear":
				System.out.println("***Listing customers near Meridian branch***");
				mgr.listNearMeridian();
				mgr.emClose();
				break;
			case "listsome":
				System.out.println("***Listing some customers***");
				mgr.listSomeCustomers();
				mgr.emClose();
				break;
			case "listall":
				System.out.println("***Listing all customers***");
				mgr.listAllCustomers();
				mgr.emClose();
				break;				
			default:
				mgr.help();
		}

		mgr.closeEntityManager();
		System.exit(0);
	}


	private void listNearMeridian() {
		String sql;
		sql = "select e.name, e.street, e.city from Customer e where dwithin(e.location, (select b.location from Bank b where b.name = 'Meridian'),2000) = true";
		System.out.println("*** Hibernate SQL: '" + sql + "'\n*** Generated DB2 SQL:");
		Query query = em.createQuery( sql );
		List list = query.getResultList();
		Iterator<Object[]> it = list.iterator();
		int customerCount = 0;
		while (it.hasNext()) {
			customerCount++;
			Object[] row = it.next();
			String name = (String) row[0];
			String street = (String) row[1];
			String city = (String) row[2];
			System.out.println(customerCount + "; name: " + name + "; address: " +
					street + "; city: " + city);
		}
		return;
	}
	
	private void listSomeCustomers() {
		String sql;
		sql = "select e from Customer e where within(e.location, db2gse.st_polygon('POLYGON ((-122.0 37.3, -121.9 37.3, -121.9 37.4, -122.0 37.4, -122.0 37.3))',4326)) = true";
		System.out.println("*** Hibernate SQL: '" + sql + "'\n*** Generated DB2 SQL:");
		Query query = em.createQuery( sql, Customer.class );
		List customers = (List<Customer>)query.getResultList();
		int customerCount = customers.size();
		System.out.println("\n*** " + customerCount + " customers found");
		for (int i = 0; i < customerCount; i++) {
			Customer customer = (Customer) customers.get(i);
			System.out.println("Customer " + (i + 1) + ": " + customer.getName() +
					", Location: " + customer.getLocation());
		}
	}
	
	private void listAllCustomers() {
		String sql;
		sql = "select e from Customer e";
		System.out.println("*** Hibernate SQL: '" + sql + "'\n*** Generated DB2 SQL:");
		Query query = em.createQuery( sql, Customer.class );
		List customers = (List<Customer>)query.getResultList();
		int customerCount = customers.size();
		int maxList = 10;
		System.out.println("\n*** " + customerCount + " customers found, only listing first " + maxList + " customers");
		if (customerCount > maxList) customerCount = maxList;
		for (int i = 0; i < customerCount; i++) {
			Customer customer = (Customer) customers.get(i);
			System.out.println("Customer " + (i + 1) + ": " + customer.getName() +
					", Location: " + customer.getLocation());
		}
	}


	/**
	 * Internal support methods
	 */

	private void help() {
		System.out.println("An operation parameter must be specified:");
		System.out.println("  listnear, listsome, listall");
	}
	/**
	 * Create an Entity Manager Factory
	 */
	private EntityManagerFactory getEmFactory() {
		if (emFactory == null) {
			URL resource = Thread.currentThread().getContextClassLoader().getResource("META-INF/persistence.xml");
			if (resource == null)
				throw new RuntimeException("No persistence.xml file found");
			try {
				emFactory = (Persistence.createEntityManagerFactory("SPATIAL-JPA"));
				System.out.println("Created EntityManagerFactory");
			} catch (Throwable ex) {
				System.err.println("Cannot create EntityManagerFactory.");
				throw new ExceptionInInitializerError(ex);
			}
		}
		return emFactory;
	}

	/** 
	 * Create an Entity Manager
	 */
	private void createEntityManager() {
		em = getEmFactory().createEntityManager();
		System.out.println("Created EntityManager");
	}
	
	/** 
	 * Close the Entity Manager
	 */
	private void closeEntityManager() {
		getEmFactory().close();
		System.out.println("Closed entity manager factory\n");
	}

	private void emClose() {
		em.close();
		System.out.println("Closed entity manager\n");
	}
}
