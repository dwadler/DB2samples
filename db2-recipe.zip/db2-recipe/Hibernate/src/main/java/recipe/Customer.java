package recipe;

import org.locationtech.jts.geom.Point;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;


/**
 * @author David Adler
 *         creation-date: 03/22/2018
 */
@Entity
@Table( name = "CUSTOMERS" )
public class Customer {

        @Id
		@Column(name = "OBJECTID")

        @GenericGenerator(name="increment", strategy = "increment")
        private Long id;

        private String name;
        private String street;
        private String city;

		@Column(name = "GEOM")
        private Point location;

        public Customer() {
        }

        public Long getId() {
            return id;
        }

        private void setId(Long id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public Point getLocation() {
            return this.location;
        }

        public void setLocation(Point location) {
            this.location = location;
        }
}